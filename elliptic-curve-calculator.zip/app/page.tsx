"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent } from "@/components/ui/card"
import EllipticCurveGraph from "@/components/elliptic-curve-graph"

export default function Home() {
  const [currentScreen, setCurrentScreen] = useState(1)
  const [a, setA] = useState<number | undefined>()
  const [b, setB] = useState<number | undefined>()
  const [p, setP] = useState<number | undefined>()
  const [warning, setWarning] = useState("")
  const [previousValues, setPreviousValues] = useState("")
  const [points, setPoints] = useState<Array<{ x: number; y: number }>>([])

  const goToScreen = (screenNumber: number) => {
    setCurrentScreen(screenNumber)
    if (screenNumber === 5) {
      calculatePoints()
    }
  }

  const validateAndCalculate = () => {
    if (a === undefined || b === undefined || p === undefined) {
      setWarning("Lütfen tüm değerleri doldurunuz.")
      return
    }

    if (p > 97) {
      setWarning("p değeri çok büyük. Lütfen 97 veya daha küçük bir asal sayı giriniz.")
      return
    }

    setWarning("")
    setPreviousValues(`Önceki işlem: a=${a}, b=${b}, p=${p}`)
    goToScreen(5)
  }

  const calculatePoints = () => {
    if (a === undefined || b === undefined || p === undefined) return

    const newPoints = []
    for (let x = 0; x < p; x++) {
      const rhs = (Math.pow(x, 3) + a * x + b) % p
      for (let y = 0; y < p; y++) {
        if ((y * y) % p === rhs) {
          newPoints.push({ x, y })
        }
      }
    }
    setPoints(newPoints)
  }

  const resetCalculation = () => {
    setA(undefined)
    setB(undefined)
    setP(undefined)
    goToScreen(4)
  }

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-r from-[#0f2027] via-[#203a43] to-[#2c5364] p-4 py-8">
      <Card className="max-w-md w-full bg-[#112240] border-none shadow-[0_0_25px_rgba(0,255,255,0.2)]">
        <CardContent className="p-4 sm:p-6">
          {/* Screen 1: Introduction */}
          {currentScreen === 1 && (
            <div className="text-center">
              <h1 className="text-xl sm:text-2xl font-bold text-[#64ffda] mb-4">Eliptik Eğri Nokta Hesaplayıcı</h1>

              <Link
                href="https://www.canva.com/design/DAGkgL2uD8Q/hT13S5C4yNSlDSluM2ZLTQ/edit"
                target="_blank"
                className="block bg-[#0a192f] text-[#64ffda] p-3 my-2 rounded-lg border border-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
              >
                Sunum
              </Link>

              <Link
                href="https://www.canva.com/design/DAGkgc11iZM/yVXr2J_8_AG9eQZ88CxPiQ/edit"
                target="_blank"
                className="block bg-[#0a192f] text-[#64ffda] p-3 my-2 rounded-lg border border-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
              >
                Broşür
              </Link>

              <Link
                href="https://www.renderforest.com/tr/watch-98882840?queue_id=138449971&quality=0"
                target="_blank"
                className="block bg-[#0a192f] text-[#64ffda] p-3 my-2 rounded-lg border border-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
              >
                Tanıtım Videosu
              </Link>

              <div className="bg-[#0a192f] p-3 sm:p-5 mt-4 rounded-lg text-xs sm:text-sm leading-relaxed">
                <strong>"Eliptik Eğrilerle Nokta Hesaplayıcı"</strong>
                <br />
                <br />
                Bu uygulama, matematiksel olarak karmaşık görünen eliptik eğrileri anlaşılır hale getirir.
                <br />
                <br />
                <strong>Amacı:</strong>
                <br />
                Eliptik eğri denklemlerini (y² = x³ + ax + b mod p) kullanarak noktaları hesaplamak, bu noktaları grafik
                üzerinde göstermek ve modüler aritmetiği basit örneklerle açıklamaktır.
                <br />
                <br />
                Hazırlayan: <strong>Fatma Başak Gürdamur</strong>
                <br />
                Doğan Cüceloğlu Fen Lisesi Öğrencisi
              </div>

              <Button onClick={() => goToScreen(2)} className="mt-4 bg-[#64ffda] text-[#0a192f] hover:bg-[#4ecdc4]">
                Başla
              </Button>
            </div>
          )}

          {/* Screen 2: What are Elliptic Curves */}
          {currentScreen === 2 && (
            <div className="text-center">
              <h2 className="text-lg sm:text-xl font-bold text-[#64ffda] mb-4">Eliptik Eğriler Nedir?</h2>
              <p className="mb-3">
                Eliptik eğriler, matematikte y² = x³ + ax + b şeklinde tanımlanan özel denklemlerdir. Bu eğriler,
                düzlemde simetrik ve sürekli bir yapı oluşturur.
              </p>
              <p className="mb-3">
                Her eliptik eğri, bir sabit asal sayı p'ye göre modüler olarak da tanımlanabilir ve bu özellik onu
                kriptografi gibi alanlarda önemli kılar.
              </p>
              <p className="mb-4">
                Eliptik eğriler üzerindeki noktalar, birbirleriyle toplanarak yeni noktalar üretir. Bu işlem
                matematiksel olarak tanımlıdır ve toplama işlemi grup yapısı oluşturur.
              </p>

              <div className="flex flex-col sm:flex-row justify-center gap-2">
                <Button
                  onClick={() => goToScreen(1)}
                  variant="outline"
                  className="border-[#64ffda] text-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
                >
                  Geri
                </Button>
                <Button
                  onClick={() => goToScreen(3)}
                  className="bg-[#64ffda] text-[#0a192f] hover:bg-[#4ecdc4] mt-2 sm:mt-0"
                >
                  İleri
                </Button>
              </div>
            </div>
          )}

          {/* Screen 3: What is Modular Arithmetic */}
          {currentScreen === 3 && (
            <div className="text-center">
              <h2 className="text-lg sm:text-xl font-bold text-[#64ffda] mb-4">Modüler Aritmetik Nedir?</h2>
              <p className="mb-3">
                Modüler aritmetik, sayılarla yapılan işlemlerin belirli bir sayıya (mod) göre tekrar ettiği sistemdir.
                Bu sisteme saat aritmetiği de denir.
              </p>
              <p className="mb-3">
                Örneğin, 12 saatlik bir saat düşünün. Saat 10'a 5 saat eklersek 15 değil, 3 olur. Çünkü 15 mod 12 =
                3'tür.
              </p>
              <p className="mb-4">
                Eliptik eğrilerde bu sistem sayesinde çok büyük sayılarla işlem yapmadan sonuçlar alınabilir.
              </p>

              <div className="flex flex-col sm:flex-row justify-center gap-2">
                <Button
                  onClick={() => goToScreen(2)}
                  variant="outline"
                  className="border-[#64ffda] text-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
                >
                  Geri
                </Button>
                <Button
                  onClick={() => goToScreen(4)}
                  className="bg-[#64ffda] text-[#0a192f] hover:bg-[#4ecdc4] mt-2 sm:mt-0"
                >
                  İleri
                </Button>
              </div>
            </div>
          )}

          {/* Screen 4: Calculate */}
          {currentScreen === 4 && (
            <div className="text-center">
              <div className="text-xs sm:text-sm bg-[#0a192f] p-3 sm:p-4 rounded-lg mb-4 text-left leading-relaxed">
                <strong>a:</strong> Eliptik eğri denkleminde (y² = x³ + ax + b) x² teriminin katsayısını etkileyen
                sabittir. Eğrinin şeklini belirler.
                <br />
                <strong>b:</strong> Denklemin sabit terimidir. Eğrinin konumunu etkiler.
                <br />
                <strong>p:</strong> Modüler aritmetikte kullanılan asal sayıdır. İşlemler bu sayı ile sınırlı yapılır
                (örneğin saat mantığı gibi).
              </div>

              <h2 className="text-lg sm:text-xl font-bold text-[#64ffda] mb-4">Hesapla</h2>

              <div className="flex flex-col sm:flex-row justify-center items-center gap-2 mb-4">
                <div className="flex items-center gap-2 my-1">
                  <span>a:</span>
                  <Input
                    type="number"
                    value={a === undefined ? "" : a}
                    onChange={(e) => setA(e.target.value ? Number.parseInt(e.target.value) : undefined)}
                    className="w-20 text-center"
                  />
                </div>

                <div className="flex items-center gap-2 my-1">
                  <span>b:</span>
                  <Input
                    type="number"
                    value={b === undefined ? "" : b}
                    onChange={(e) => setB(e.target.value ? Number.parseInt(e.target.value) : undefined)}
                    className="w-20 text-center"
                  />
                </div>

                <div className="flex items-center gap-2 my-1">
                  <span>p:</span>
                  <Input
                    type="number"
                    value={p === undefined ? "" : p}
                    onChange={(e) => setP(e.target.value ? Number.parseInt(e.target.value) : undefined)}
                    className="w-20 text-center"
                  />
                </div>
              </div>

              {warning && <p className="text-pink-300 mb-3">{warning}</p>}

              <div className="flex flex-col sm:flex-row justify-center gap-2 mt-4">
                <Button
                  onClick={() => goToScreen(3)}
                  variant="outline"
                  className="border-[#64ffda] text-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
                >
                  Geri
                </Button>
                <Button
                  onClick={validateAndCalculate}
                  className="bg-[#64ffda] text-[#0a192f] hover:bg-[#4ecdc4] mt-2 sm:mt-0"
                >
                  Hesapla
                </Button>
              </div>

              {previousValues && <p className="text-[#a2d2ff] text-sm mt-3">{previousValues}</p>}
            </div>
          )}

          {/* Screen 5: Graph */}
          {currentScreen === 5 && (
            <div className="text-center">
              <h2 className="text-lg sm:text-xl font-bold text-[#64ffda] mb-4">Grafik</h2>

              <EllipticCurveGraph a={a || 0} b={b || 0} p={p || 0} points={points} />

              <div className="mt-3 mb-4 text-sm">
                {points.length > 0 ? (
                  <div>
                    <p>Bulunan Noktalar:</p>
                    <div className="max-h-32 overflow-y-auto mt-2 p-2 bg-[#0a192f] rounded-lg text-xs sm:text-sm">
                      {points.map((point, index) => (
                        <span key={index} className="inline-block m-1">
                          ({point.x},{point.y})
                        </span>
                      ))}
                    </div>
                  </div>
                ) : (
                  <p className="text-xs sm:text-sm px-2">
                    Çözüm bulunamadı. Çünkü bu a, b, p değerleriyle geçerli bir eliptik eğri tanımı yapılmamış olabilir.
                    Lütfen başka değerlerle deneyiniz.
                  </p>
                )}
              </div>

              <div className="flex flex-col sm:flex-row justify-center gap-2">
                <Button
                  onClick={resetCalculation}
                  variant="outline"
                  className="border-[#64ffda] text-[#64ffda] hover:bg-[#64ffda] hover:text-[#0a192f]"
                >
                  Yeniden Hesapla
                </Button>
                <Button
                  onClick={() => goToScreen(6)}
                  className="bg-[#64ffda] text-[#0a192f] hover:bg-[#4ecdc4] mt-2 sm:mt-0"
                >
                  Çıkış
                </Button>
              </div>
            </div>
          )}

          {/* Screen 6: Thank You */}
          {currentScreen === 6 && (
            <div className="text-center">
              <h2 className="text-lg sm:text-xl font-bold text-[#64ffda] mb-4">Teşekkürler</h2>
              <p className="mb-4">Uygulamayı kullandığınız için teşekkür ederiz.</p>

              <Button onClick={() => goToScreen(1)} className="bg-[#64ffda] text-[#0a192f] hover:bg-[#4ecdc4]">
                Başa Dön
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}
