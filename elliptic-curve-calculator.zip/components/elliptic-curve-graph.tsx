"use client"

import { useEffect, useRef, useState } from "react"

interface EllipticCurveGraphProps {
  a: number
  b: number
  p: number
  points: Array<{ x: number; y: number }>
}

export default function EllipticCurveGraph({ a, b, p, points }: EllipticCurveGraphProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [canvasSize, setCanvasSize] = useState({ width: 400, height: 400 })

  // Add resize handler
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 500) {
        const size = Math.min(window.innerWidth - 40, 320)
        setCanvasSize({ width: size, height: size })
      } else {
        setCanvasSize({ width: 400, height: 400 })
      }
    }

    // Initial size
    handleResize()

    // Add event listener
    window.addEventListener("resize", handleResize)

    // Cleanup
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Update canvas dimensions
    canvas.width = canvasSize.width
    canvas.height = canvasSize.height

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Draw coordinate axes
    ctx.strokeStyle = "#ccc"
    ctx.beginPath()
    ctx.moveTo(0, canvas.height / 2)
    ctx.lineTo(canvas.width, canvas.height / 2)
    ctx.moveTo(canvas.width / 2, 0)
    ctx.lineTo(canvas.width / 2, canvas.height)
    ctx.stroke()

    // Calculate scale factor based on canvas size
    const scaleFactor = (canvasSize.width / 400) * 20

    // Draw points
    ctx.fillStyle = "#64ffda"
    points.forEach((point) => {
      const x = canvas.width / 2 + (point.x - p / 2) * scaleFactor
      const y = canvas.height / 2 - (point.y - p / 2) * scaleFactor

      ctx.beginPath()
      ctx.arc(x, y, 4, 0, Math.PI * 2)
      ctx.fill()

      // Adjust font size for smaller screens
      ctx.font = `${Math.max(10, (12 * canvasSize.width) / 400)}px sans-serif`
      ctx.fillText(`(${point.x},${point.y})`, x + 6, y - 6)
    })
  }, [a, b, p, points, canvasSize])

  return (
    <canvas
      ref={canvasRef}
      width={canvasSize.width}
      height={canvasSize.height}
      className="bg-white mx-auto border-2 border-[#64ffda] max-w-full"
    />
  )
}
